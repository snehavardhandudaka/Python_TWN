import random

def guessing_game():
    # Generate a random number between 1 and 9
    number_to_guess = random.randint(1, 9)
    attempts = 0

    while True:
        # Ask the user to guess the number
        user_guess = input("Guess a number between 1 and 9 (or type 'exit' to quit): ")

        if user_guess.lower() == 'exit':
            print("Thanks for playing! Goodbye!")
            break

        try:
            user_guess = int(user_guess)
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue

        attempts += 1

        if user_guess < number_to_guess:
            print("Too low! Try again.")
        elif user_guess > number_to_guess:
            print("Too high! Try again.")
        else:
            print(f"YOU WON! You guessed the number in {attempts} attempts.")
            break

# Run the guessing game
guessing_game()
