import pandas as pd

# Step 1: Read the provided spreadsheet file
file_path = r'C:\Users\dudak\Downloads\employees.xlsx'  # Use raw string to avoid escaping backslashes
df = pd.read_excel(file_path)

# Step 2: Sort the DataFrame by 'years of experience' in descending order
df_sorted = df.sort_values(by='Years of Experience', ascending=False)

# Step 3: Select the required columns 'name' and 'years of experience'
df_sorted = df_sorted[['Name', 'Years of Experience']]

# Step 4: Write the sorted DataFrame to a new Excel file
output_file = 'employees_sorted.xlsx'
df_sorted.to_excel(output_file, index=False)

print(f"Sorted employee data has been saved to {output_file}")
