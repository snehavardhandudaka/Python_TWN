import requests

def get_github_repositories(snehavardhan1):
    url = f"https://api.github.com/users/{snehavardhan1}/repos"
    response = requests.get(url)

    if response.status_code == 200:
        repositories = response.json()
        for repo in repositories:
            print(f"Repository Name: {repo['name']}")
            print(f"Repository URL: {repo['html_url']}\n")
    else:
        print(f"Failed to fetch repositories for user '{username}'. Status Code: {response.status_code}")

if __name__ == "__main__":
    github_username = input("Enter the GitHub username: ")
    get_github_repositories(github_username)
 