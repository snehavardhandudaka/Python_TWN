from datetime import datetime


def days_until_birthday(birthday_str):
    birthday = datetime.strptime(birthday_str, "%d/%m/%Y")
    now = datetime.now()
    next_birthday = datetime(year=now.year, month=birthday.month, day=birthday.day)

    if next_birthday < now:
        next_birthday = datetime(year=now.year + 1, month=birthday.month, day=birthday.day)

    remaining_time = next_birthday - now
    days, seconds = remaining_time.days, remaining_time.seconds
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60

    print(f"Time until birthday: {days} days, {hours} hours, and {minutes} minutes")


birthday_input = input("Enter your birthday (DD/MM/YYYY): ")
days_until_birthday(birthday_input)
