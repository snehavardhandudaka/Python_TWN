# List of dictionaries
employees = [
    {
        "name": "Tina",
        "age": 30,
        "birthday": "1990-03-10",
        "job": "DevOps Engineer",
        "address": {
            "city": "New York",
            "country": "USA"
        }
    },
    {
        "name": "Tim",
        "age": 35,
        "birthday": "1985-02-21",
        "job": "Developer",
        "address": {
            "city": "Sydney",
            "country": "Australia"
        }
    }
]
# Print name, job, and city of each employee
print("Employee details:")
for employee in employees:
    name = employee["name"]
    job = employee["job"]
    city = employee["address"]["city"]
    print(f"Name: {name}, Job: {job}, City: {city}")
# Print the country of the second employee
second_employee_country = employees[1]["address"]["country"]
print(f"\nCountry of the second employee: {second_employee_country}")

