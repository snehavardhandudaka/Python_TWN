employee = {
    "name": "Tim",
    "age": 30,
    "birthday": "1990-03-10",
    "job": "DevOps Engineer"
}
# Update job to Software Engineer
employee["job"] = "Software Engineer"
# Remove the age key
del employee["age"]
# Loop through the dictionary and print key:value pairs
for key, value in employee.items():
    print(f"{key}: {value}")
print("----------------------")
dict_one = {'a': 100, 'b': 400}
dict_two = {'x': 300, 'y': 200}
# Merge the two dictionaries
merged_dict = {**dict_one, **dict_two}
# Sum up all the values in the new dictionary
total_sum = sum(merged_dict.values())
# Print the sum, max, and min values
print("Exercise 2 Results:")
print(f"Merged Dictionary: {merged_dict}")
print(f"Sum of values: {total_sum}")
print(f"Max value: {max(merged_dict.values())}")
print(f"Min value: {min(merged_dict.values())}")
