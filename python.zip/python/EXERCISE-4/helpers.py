# Function to find the youngest employee
def find_youngest_employee(employees):
    if not employees:
        print("No employees in the list.")
        return

    youngest_employee = min(employees, key=lambda e: e['age'])
    print(f"Youngest Employee - Name: {youngest_employee['name']}, Age: {youngest_employee['age']}")


# Function to count upper and lower case letters
def count_case_letters(s):
    upper_count = sum(1 for char in s if char.isupper())
    lower_count = sum(1 for char in s if char.islower())
    return upper_count, lower_count


# Function to print even numbers from a list
def print_even_numbers(numbers):
    even_numbers = [num for num in numbers if num % 2 == 0]
    print("Even numbers:", even_numbers)
