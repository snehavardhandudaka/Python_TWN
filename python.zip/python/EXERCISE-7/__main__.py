# main.py

# Import classes from university_system.py
from university_system import Student, Professor, Lecture

# Create Student, Professor, and Lecture objects
student = Student("John", "Doe", 20)
professor = Professor("Dr.", "Smith", 45)
lecture = Lecture("Math 101", 30, 2)

# Work with Student object
student.print_name()  # Expected output: "John Doe"
student.add_lecture("Math 101")  # Expected output: "Added lecture: Math 101"
student.list_lectures()  # Expected output: "Lectures attended: \n - Math 101"

# Work with Professor object
professor.print_name()  # Expected output: "Dr. Smith"
professor.add_subject("Calculus")  # Expected output: "Added subject: Calculus"
professor.list_subjects()  # Expected output: "Subjects taught: \n - Calculus"

# Work with Lecture object
lecture.print_details()  # Expected output: "Lecture: Math 101, Duration: 2 hours"
lecture.add_professor(professor)  # Expected output: "Added professor: Dr. Smith"
