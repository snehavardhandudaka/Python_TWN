class Person:
    def __init__(self, first_name, last_name, age):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age

    def print_name(self):
        print(f"{self.first_name} {self.last_name}")


class Student(Person):
    def __init__(self, first_name, last_name, age):
        super().__init__(first_name, last_name, age)
        self.lectures = []

    def list_lectures(self):
        print("Lectures attended:")
        for lecture in self.lectures:
            print(f"- {lecture}")

    def add_lecture(self, lecture):
        self.lectures.append(lecture)
        print(f"Added lecture: {lecture}")

    def remove_lecture(self, lecture):
        if lecture in self.lectures:
            self.lectures.remove(lecture)
            print(f"Removed lecture: {lecture}")
        else:
            print(f"Lecture not found: {lecture}")


class Professor(Person):
    def __init__(self, first_name, last_name, age):
        super().__init__(first_name, last_name, age)
        self.subjects = []

    def list_subjects(self):
        print("Subjects taught:")
        for subject in self.subjects:
            print(f"- {subject}")

    def add_subject(self, subject):
        self.subjects.append(subject)
        print(f"Added subject: {subject}")

    def remove_subject(self, subject):
        if subject in self.subjects:
            self.subjects.remove(subject)
            print(f"Removed subject: {subject}")
        else:
            print(f"Subject not found: {subject}")


class Lecture:
    def __init__(self, name, max_students, duration):
        self.name = name
        self.max_students = max_students
        self.duration = duration
        self.professors = []

    def print_details(self):
        print(f"Lecture: {self.name}, Duration: {self.duration} hours")

    def add_professor(self, professor):
        self.professors.append(professor)
        print(f"Added professor: {professor.first_name} {professor.last_name}")
