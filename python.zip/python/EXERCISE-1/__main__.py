my_list = [1, 2, 2, 4, 4, 5, 6, 8, 10, 13, 22, 35, 52, 83]
new_list = []
for element in my_list:
    if element >= 10:
        new_list.append(element)
print(new_list)

#nstead of printing the elements one by one, make a new list that has all the elements higher than or equal to 10 from this list in it and print out this new list.
user_input=int(input("Enter a number: "))
filtered_list = [element for element in my_list if element > user_input]
print(f"Elements in my_list that are ", filtered_list)




